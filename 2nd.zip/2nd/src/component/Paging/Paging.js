import React from 'react';

const Paging =(props)=>{
    return (
        <div>
            <button onClick={props.leftClicked} disabled={props.hideTrue ? true : false}>&#60;&#60; </button> 
                From {props.left} to {props.right}
            <button onClick={props.rightClicked}> &#62;&#62;</button> 
        </div>
    )
}

export default Paging;