import React from 'react';

const TableTH = (props) => {
    return(
        <tr>
            <th>Album Id</th>
            <th>Title</th>
            <th>URL</th>
            <th>Thumbnai lUrl</th>
            <th>DELETE</th>
        </tr>
    )
}

export default TableTH;