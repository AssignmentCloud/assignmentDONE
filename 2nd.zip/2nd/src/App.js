import React from 'react';
import './App.css';
import './component/TableDisplay/TableDisplay.css';
import './component/Paging/Paging.css';

//component
import TableDisplay from './component/TableDisplay/TableDisplay';
import TableTH from './component/TableDisplay/TableTH';

import Paging from './component/Paging/Paging'

// JSON Data 
const URL_DATA = 'http://jsonplaceholder.typicode.com/photos';

class App extends React.Component {
  state = {
    posts_data : '',
    position_status : 0,
    freq  : 5,
    pass : false
  }

  componentDidMount(){
    this.fetchDataFromURL(this.state.start, this.state.freq);
  }

  deleteRow = (id) =>
  {
    const tmpTd = [...this.state.posts_data];
    tmpTd.splice(id,1);
    this.setState({posts_data:tmpTd});
  }

  leftClicked = () =>{
    let left = false;
    this.fetchDataFromURL(this.state.position_status - 5 ,this.state.freq,left)
  }

  rightClicked = () => {
    let right = true;
    this.fetchDataFromURL(this.state.position_status + 5 ,this.state.freq,right)
  }

  fetchDataFromURL = (left, right, position) =>{
    fetch(`${URL_DATA}/?_start=${left}&_limit=${right}`,{
          method: 'GET'
      })
      .then(response => response.json())
      .then(data => {
          this.setState({
              posts_data:data,
              position_status : position !== true && position !== false ? this.state.position_status : left,
              pass: left === 0 ||( this.state.position_status === 0 && (position !== true && position !== false) )? true : false
          })
      })
      .catch(function(error) {
          console.error(error);
      });

  }

  render(){
    let outputTable = null;
    let tableTh  = null;

    if(this.state.posts_data)
    {
      tableTh = <TableTH />;
      outputTable = this.state.posts_data.map((data,index) => {
        return (
          <TableDisplay 
            data={data} 
            key={index} 
            del={index}
            onclicked={this.deleteRow}
          />
        )
      })
    }  

    return (
      <div className="App">
          <table id='dataTable'>
                <tbody>
                    {tableTh}
                    {outputTable}
                </tbody>
            </table>

            <Paging leftClicked={this.leftClicked} 
                    rightClicked={this.rightClicked} 
                    hideTrue={this.state.pass}/>
      </div>
    );
  }
}

export default App;
