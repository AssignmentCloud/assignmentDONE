import React from 'react';

const TableDisplay = (props) => {
    console.log(props);

    return(
        <tr key={props.data.id}>
            <td>{props.data.albumId}</td>
            <td>{props.data.title}</td>
            <td>{props.data.url}</td>
            <td>{props.data.thumbnailUrl}</td>
            <td onClick={()=>props.onclicked(props.del)}>DEL</td>
        </tr>
    )
}

export default TableDisplay;